package com.example.recyclerviewtest.util;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.provider.Settings;

import androidx.appcompat.app.AlertDialog;

/**
 * Created by Administrator on 2/27/2018.
 */

public class InternetConnectionDetector {

    private Context context;
    public InternetConnectionDetector(Context context) {
        this.context = context;
    }
    /**
     * Checking for all possible Internet providers
     * **/

    public boolean isConnectedToInternet(){
        ConnectivityManager connectivity =(ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        if (connectivity != null)
        {
            NetworkInfo[] infos = connectivity.getAllNetworkInfo();
            if (infos!= null){
                for (int i=0;i<infos.length;i++)
                    if (infos[i].getState()== NetworkInfo.State.CONNECTED){
                        return  true;
                    }
            }
        }

        return false;
    }

    /**
     * Function to show settings alert dialog On pressing Settings button will
     * lauch Settings Options
     * */

    public void showInternetSettingDialog(){

        AlertDialog.Builder alertDialog = new AlertDialog.Builder(context);

        alertDialog.setTitle("Internet Settings");

        //show message

        alertDialog.setMessage("Internet connection is not enabled. Do you want to go to settings menu?");

        //set Positive Button

        alertDialog.setPositiveButton("Setting", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent intent = new Intent(Settings.ACTION_WIRELESS_SETTINGS);
                context.startActivity(intent);
            }
        });

        //set Negative button

        alertDialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        alertDialog.show();

    }


}
