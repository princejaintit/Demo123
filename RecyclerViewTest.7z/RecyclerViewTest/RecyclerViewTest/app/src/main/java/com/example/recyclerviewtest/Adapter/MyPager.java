package com.example.recyclerviewtest.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.PagerAdapter;

import com.example.recyclerviewtest.Activity.TestActivity;
import com.example.recyclerviewtest.Model.WEEK1;
import com.example.recyclerviewtest.Model.WeeK;
import com.example.recyclerviewtest.R;

import java.util.ArrayList;

public class MyPager extends PagerAdapter {
    private Context context;
    private  ArrayList<ArrayList<WEEK1>>  weeKArrayList;
    private LayoutInflater layoutInflater;
   // private Week1Adapter week1Adapter;

    public MyPager(Context context,  ArrayList<ArrayList<WEEK1>>  weeKArrayList) {
        this.context = context;
        this.weeKArrayList=weeKArrayList;
        layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }
    @Override
    public int getCount() {
        return weeKArrayList.size();
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        return view == object;
    }

    @Override
    public Object instantiateItem(ViewGroup container, final int position) {
        View view = layoutInflater.inflate(R.layout.view_pager, container, false);

      RecyclerView view_pager_recy= view.findViewById((R.id.view_pager_recy));
         LinearLayoutManager layoutManager = new LinearLayoutManager(context,LinearLayoutManager.VERTICAL,false);
        view_pager_recy.setLayoutManager(layoutManager);

        Week1Adapter week1Adapter=new Week1Adapter(context,weeKArrayList.get(position));
        view_pager_recy.setAdapter(week1Adapter);
        container.addView(view);
        return view;

//        View itemView = layoutInflater.inflate(R.layout.item, container, false);
//
//        ImageView imageView = (ImageView) itemView.findViewById(R.id.imageView);
//        imageView.setImageResource(images[position]);
//
//        container.addView(itemView);

        //listening to image click


      //  return itemView;
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((View) object);
    }

//    @Override
//    public Object instantiateItem(ViewGroup container, final int position) {
//        View view = LayoutInflater.from(context).inflate(R.layout.view_pager, null);
//
//      RecyclerView view_pager_recy= view.findViewById((R.id.view_pager_recy));
//         LinearLayoutManager layoutManager = new LinearLayoutManager(context,LinearLayoutManager.HORIZONTAL,false);
//        view_pager_recy.setLayoutManager(layoutManager);
//
//        Week1Adapter week1Adapter=new Week1Adapter(context,weeKArrayList.get(position));
//        view_pager_recy.setAdapter(week1Adapter);
//        container.addView(view);
//        return view;
//    }


}
