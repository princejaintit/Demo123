package com.example.recyclerviewtest.util;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Created by prince on 3/31/2016.
 */
public class SharedPreferenceManager {
    private static final String PREFERENCE_FILE_NAME = "idemia_Pref";
    private static final String User_id = "";
    private static final String Token = "";
    boolean result = false;
    private Context context;
    private String res = "";
    SharedPreferences sharedPreferences;

    public SharedPreferenceManager(Context context) {
        this.context = context;
        sharedPreferences = context.getSharedPreferences("LoginDetails", context.MODE_PRIVATE);
    }

    public void saveLoginDetails(String empNo,String empName,String department,String location) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("EMP_NO", empNo);
        editor.putString("EMP_NAME", empName);
        editor.putString("DEPARTMENT", department);
        editor.putString("LOCATION", location);
        editor.commit();
    }

    public String getDeviceID(){
        return sharedPreferences.getString("DEVICEID", "") ;
    }

    public String getEmpNo() {
        return sharedPreferences.getString("EMP_NO", "") ;
    }

    public String getToken() {
        return sharedPreferences.getString("TOKEN", "");
    }
    public String getUserType() {
        return sharedPreferences.getString("USERTYPE", "");
    }
    public String getDepartment() {
        return sharedPreferences.getString("DEPARTMENT", "");
    }
    public String getLocation() {
        return sharedPreferences.getString("LOCATION", "");
    }

    public String getEmpName() {
        return sharedPreferences.getString("EMP_NAME", "");
    }



    public void  clearPreference(){
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.clear();
        editor.commit();
    }

}
