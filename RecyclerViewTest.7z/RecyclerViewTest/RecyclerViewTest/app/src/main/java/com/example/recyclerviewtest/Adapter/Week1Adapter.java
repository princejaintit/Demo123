package com.example.recyclerviewtest.Adapter;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.recyclerviewtest.Model.WEEK1;
import com.example.recyclerviewtest.Model.WEEK2;
import com.example.recyclerviewtest.R;
import com.example.samparkapp.util.RecyclerTouchListener;
import org.jetbrains.annotations.NotNull;
import java.util.ArrayList;

public class Week1Adapter extends RecyclerView.Adapter<Week1Adapter.MyViewHolder> {
    private ArrayList<WEEK1> week1ArrayList;
    private ArrayList<WEEK2> week2s;
    Context ctx;
    private LayoutInflater inflater;
    private String TAG = "Week1Adapter";
    MonthlyReportVerticalData monthlyReportVerticalData;
    final int VIEW_TYPE_WEEK1 = 0;
    final int VIEW_TYPE_WEEK2 = 1;


    public Week1Adapter(Context ctx, ArrayList<WEEK1> week1s) {
        inflater = LayoutInflater.from(ctx);
        this.week1ArrayList = week1s;
        this.ctx = ctx;
    }


    @NonNull
    @Override
    public Week1Adapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        Log.d(TAG, "ViewType" + viewType);
        View view = inflater.inflate(R.layout.monthly_report_vertical_data_layout, parent, false);
        Week1Adapter.MyViewHolder holder = new Week1Adapter.MyViewHolder(view);
        return holder;
    }


    public static class Week1ViewHolder extends RecyclerView.ViewHolder {

        public Week1ViewHolder(View itemView) {
            super(itemView);

        }
    }

    @Override
    public void onBindViewHolder(Week1Adapter.MyViewHolder holder, int position) {
        final WEEK1 week1 = week1ArrayList.get(position);
        holder.txtViewCngRs.setText(week1.getCNGRATE());
        holder.txtViewTotalSale.setText(week1.getTOTALSALE());
        holder.txtViewSaleValue.setText(week1.getSALEVALUE());
        holder.txtViewByCash.setText(week1.getBYCASH());
        holder.txtViewByPos.setText(week1.getBYPOS());
        holder.txtViewByPaytm.setText(week1.getBYPAYTM());


      /*  if(week1.getCashDepositAmount().equals("NA")||week1.getCashDepositAmount().equals("0")){
            holder.txtViewCashDepositAmount.setText(week1.getCashDepositAmount());
        }else {*/
        holder.txtViewCashDepositAmount.setText(week1.getCASHDEPOSITEBANK());
        // }
   /*     if(week1.getRtgsAmount().equals("NA")||week1.getRtgsAmount().equals("0")){
            holder.txtViewRtgsBankAmount.setText(week1.getRtgsAmount());
        }
        else {*/
        holder.txtViewRtgsBankAmount.setText(week1.getRTGSTOBANK());
        // }
       /* if(week1.getTotalDepositToBank().equals("NA")||week1.getTotalDepositToBank().equals("0")){
            holder.txtViewTotalDepositAmount.setText(week1.getTotalDepositToBank());
        }
        else {
            holder.txtViewTotalDepositAmount.setText(String.format("%.2f",Double.parseDouble(week1.getTotalDepositToBank())));
        }*/
        // holder.txtViewCashDepositBankName.setText(week1.getCashDepositBankName());
        // holder.txtViewRtgsBankName.setText(week1.getRtgsBankName());
        holder.txtViewTotalDepositAmount.setText(week1.getTOTALDEPOSITEBANK());
        holder.txtViewClosingCashInHandAmount.setText(week1.getCLOSINGCASH());
        holder.txtViewDate.setText(week1.getCREATEDON());
    }


    @Override
    public int getItemCount() {
      //  Log.d(TAG, "week1ArrayListSize " + week1ArrayList.size());
        return week1ArrayList.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder {
        TextView txtViewDate, txtViewCngRs, txtViewTotalSale, txtViewByCash, txtViewByPos, txtViewByPaytm,
                txtViewCashDepositAmount, txtViewCashDepositBankName, txtViewRtgsBankAmount, txtViewRtgsBankName,
                txtViewTotalDepositAmount,
                txtViewSaleValue, txtViewClosingCashInHandAmount;

        public MyViewHolder(View itemView) {
            super(itemView);
            // recyclerView=(RecyclerView)itemView.findViewById(R.id.recyclerView_monthly_report_vertically_adapter);
            txtViewCngRs = (TextView) itemView.findViewById(R.id.txt_view_cng_rs);
            txtViewTotalSale = (TextView) itemView.findViewById(R.id.txt_view_total_sale_amount);
            txtViewSaleValue = (TextView) itemView.findViewById(R.id.txt_view_sale_value);
            txtViewByCash = (TextView) itemView.findViewById(R.id.txt_view_by_cash);
            txtViewByPos = (TextView) itemView.findViewById(R.id.txt_view_by_pos);
            txtViewByPaytm = (TextView) itemView.findViewById(R.id.txt_view_by_paytm);
            txtViewCashDepositAmount = (TextView) itemView.findViewById(R.id.txt_view_cash_deposit_amount);
            //txtViewCashDepositBankName=(TextView)itemView.findViewById(R.id.txt_view_cash_deposit_bank_name);
            txtViewRtgsBankAmount = (TextView) itemView.findViewById(R.id.txt_view_rtgs_bank_amt);
            //txtViewRtgsBankName=(TextView)itemView.findViewById(R.id.txt_view_rtgs_bank_name);
            txtViewTotalDepositAmount = (TextView) itemView.findViewById(R.id.txt_view_total_deposit_amount);
            txtViewClosingCashInHandAmount = (TextView) itemView.findViewById(R.id.txt_view_total_closing_cash_in_hand_amount);
            txtViewDate = (TextView) itemView.findViewById(R.id.txt_view_date);
        }
    }

}
