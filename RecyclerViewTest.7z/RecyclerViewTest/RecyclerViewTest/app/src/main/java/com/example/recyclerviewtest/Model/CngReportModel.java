package com.example.recyclerviewtest.Model;

public class CngReportModel {
    public String cngRs;
    public String totalSale;
    public String saleValue;
    public String byCash;
    public String byPos;
    public String byPaytm;
    public String cashDepositBankName;
    public String CashDepositAmount;
    public String rtgsBankName;
    public String rtgsAmount;
    public String totalDepositToBank;
    public String closingCashInHand;
    public String date;

    public String getSaleValue() {
        return saleValue;
    }

    public void setSaleValue(String saleValue) {
        this.saleValue = saleValue;
    }

    public String getByCash() {
        return byCash;
    }

    public void setByCash(String byCash) {
        this.byCash = byCash;
    }

    public String getByPos() {
        return byPos;
    }

    public void setByPos(String byPos) {
        this.byPos = byPos;
    }

    public String getByPaytm() {
        return byPaytm;
    }

    public void setByPaytm(String byPaytm) {
        this.byPaytm = byPaytm;
    }

    public String getCashDepositBankName() {
        return cashDepositBankName;
    }

    public void setCashDepositBankName(String cashDepositBankName) {
        this.cashDepositBankName = cashDepositBankName;
    }

    public String getCashDepositAmount() {
        return CashDepositAmount;
    }

    public void setCashDepositAmount(String cashDepositAmount) {
        CashDepositAmount = cashDepositAmount;
    }

    public String getRtgsBankName() {
        return rtgsBankName;
    }

    public void setRtgsBankName(String rtgsBankName) {
        this.rtgsBankName = rtgsBankName;
    }

    public String getRtgsAmount() {
        return rtgsAmount;
    }

    public void setRtgsAmount(String rtgsAmount) {
        this.rtgsAmount = rtgsAmount;
    }

    public String getTotalDepositToBank() {
        return totalDepositToBank;
    }

    public void setTotalDepositToBank(String totalDepositToBank) {
        this.totalDepositToBank = totalDepositToBank;
    }

    public String getClosingCashInHand() {
        return closingCashInHand;
    }

    public void setClosingCashInHand(String closingCashInHand) {
        this.closingCashInHand = closingCashInHand;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getCngRs() {
        return cngRs;
    }

    public void setCngRs(String cngRs) {
        this.cngRs = cngRs;
    }

    public String getTotalSale() {
        return totalSale;
    }

    public void setTotalSale(String totalSale) {
        this.totalSale = totalSale;
    }



}
