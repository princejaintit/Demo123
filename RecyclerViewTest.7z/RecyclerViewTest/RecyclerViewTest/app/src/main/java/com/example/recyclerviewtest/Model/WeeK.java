package com.example.recyclerviewtest.Model;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.ArrayList;

public class WeeK  implements Parcelable {
    private ArrayList<WEEK1> weekArrayList;

    public WeeK(Parcel in) {
    }

    public static final Creator<WeeK> CREATOR = new Creator<WeeK>() {
        @Override
        public WeeK createFromParcel(Parcel in) {
            return new WeeK(in);
        }

        @Override
        public WeeK[] newArray(int size) {
            return new WeeK[size];
        }
    };

    public WeeK() {
        
    }

    public ArrayList<WEEK1> getWeekArrayList() {
        return weekArrayList;
    }

    public void setWeekArrayList(ArrayList<WEEK1> weekArrayList) {
        this.weekArrayList = weekArrayList;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
    }
}
