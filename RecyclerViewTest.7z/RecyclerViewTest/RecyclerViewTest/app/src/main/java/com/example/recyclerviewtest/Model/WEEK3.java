package com.example.recyclerviewtest.Model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class WEEK3 {
    @SerializedName("STATION_ID")
    @Expose
    private String sTATIONID;
    @SerializedName("CNG_RATE")
    @Expose
    private String cNGRATE;
    @SerializedName("SALE_VALUE")
    @Expose
    private String sALEVALUE;
    @SerializedName("TOTAL_SALE")
    @Expose
    private String tOTALSALE;
    @SerializedName("BY_CASH")
    @Expose
    private String bYCASH;
    @SerializedName("BY_POS")
    @Expose
    private String bYPOS;
    @SerializedName("BY_PAYTM")
    @Expose
    private String bYPAYTM;
    @SerializedName("CASH_DEPOSITE_BANK")
    @Expose
    private String cASHDEPOSITEBANK;
    @SerializedName("RTGS_TO_BANK")
    @Expose
    private String rTGSTOBANK;
    @SerializedName("TOTAL_DEPOSITE_BANK")
    @Expose
    private String tOTALDEPOSITEBANK;
    @SerializedName("CLOSING_CASH")
    @Expose
    private String cLOSINGCASH;
    @SerializedName("CREATED_ON")
    @Expose
    private String cREATEDON;

    public String getSTATIONID() {
        return sTATIONID;
    }

    public void setSTATIONID(String sTATIONID) {
        this.sTATIONID = sTATIONID;
    }

    public String getCNGRATE() {
        return cNGRATE;
    }

    public void setCNGRATE(String cNGRATE) {
        this.cNGRATE = cNGRATE;
    }

    public String getSALEVALUE() {
        return sALEVALUE;
    }

    public void setSALEVALUE(String sALEVALUE) {
        this.sALEVALUE = sALEVALUE;
    }

    public String getTOTALSALE() {
        return tOTALSALE;
    }

    public void setTOTALSALE(String tOTALSALE) {
        this.tOTALSALE = tOTALSALE;
    }

    public String getBYCASH() {
        return bYCASH;
    }

    public void setBYCASH(String bYCASH) {
        this.bYCASH = bYCASH;
    }

    public String getBYPOS() {
        return bYPOS;
    }

    public void setBYPOS(String bYPOS) {
        this.bYPOS = bYPOS;
    }

    public String getBYPAYTM() {
        return bYPAYTM;
    }

    public void setBYPAYTM(String bYPAYTM) {
        this.bYPAYTM = bYPAYTM;
    }

    public String getCASHDEPOSITEBANK() {
        return cASHDEPOSITEBANK;
    }

    public void setCASHDEPOSITEBANK(String cASHDEPOSITEBANK) {
        this.cASHDEPOSITEBANK = cASHDEPOSITEBANK;
    }

    public String getRTGSTOBANK() {
        return rTGSTOBANK;
    }

    public void setRTGSTOBANK(String rTGSTOBANK) {
        this.rTGSTOBANK = rTGSTOBANK;
    }

    public String getTOTALDEPOSITEBANK() {
        return tOTALDEPOSITEBANK;
    }

    public void setTOTALDEPOSITEBANK(String tOTALDEPOSITEBANK) {
        this.tOTALDEPOSITEBANK = tOTALDEPOSITEBANK;
    }

    public String getCLOSINGCASH() {
        return cLOSINGCASH;
    }

    public void setCLOSINGCASH(String cLOSINGCASH) {
        this.cLOSINGCASH = cLOSINGCASH;
    }

    public String getCREATEDON() {
        return cREATEDON;
    }

    public void setCREATEDON(String cREATEDON) {
        this.cREATEDON = cREATEDON;
    }

}
